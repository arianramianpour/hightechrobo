# hightechrobo

Welcome this is a reposetory of https://hightechrobo.com have fun you can easilly use it but dont forget to add a bootstarpdash copyright to it or your domain will get suspended ;)
